#!/bin/sh
echo "Deprecated use grunt 'grunt jsdoc:client_lite' instead."